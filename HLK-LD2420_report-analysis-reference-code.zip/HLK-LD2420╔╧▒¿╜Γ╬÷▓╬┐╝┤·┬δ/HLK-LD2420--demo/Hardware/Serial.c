#include "stm32f10x.h" // Device header
#include <stdio.h>
#include <stdarg.h>
#include "Serial.h"

uint8_t Serial_RxPacket[40];
uint8_t pRxHead[4];
uint8_t pRxtail[2];
uint8_t Serial_RxFlag;
uint8_t Serial2_RxFlag;

uint8_t Serial_RxData;
uint8_t Serial2_RxData;

int dataType = -1;
int date_Flag = -1;
HILINK_2420 HLK_2420;

void Serial_Init(void)
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    USART_InitTypeDef USART_InitStructure;
    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_Init(USART1, &USART_InitStructure);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStructure);

    USART_Cmd(USART1, ENABLE);

    // 初始化串口2
    // 初始化USART2（连接串口小板）
    // 启用 USART2 和 GPIOA 的时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    // 配置 GPIOA 的引脚，TX 为推挽输出模式，RX 为上拉输入模式

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // TX 引脚，推挽输出
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;       // USART2 的 TX 引脚
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; // RX 引脚，上拉输入
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;     // USART2 的 RX 引脚
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置 USART2 的初始化参数

    USART_InitStructure.USART_BaudRate = 115200;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_Init(USART2, &USART_InitStructure);

    // 使能 USART2 的接收中断
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);

    // 配置 NVIC 中断优先级
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStructure);

    // 使能 USART2
    USART_Cmd(USART2, ENABLE);
}

void Serial_SendByte(uint8_t Byte)
{
    USART_SendData(USART1, Byte);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
        ;
}

void Serial2_SendByte(uint8_t Byte)
{
    USART_SendData(USART2, Byte);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET)
        ;
}

void Serial_SendArray(uint8_t *Array, uint16_t Length)
{
    uint16_t i;
    for (i = 0; i < Length; i++)
    {
        Serial_SendByte(Array[i]);
    }
}

void Serial_SendString(char *String)
{
    uint8_t i;
    for (i = 0; String[i] != '\0'; i++)
    {
        Serial_SendByte(String[i]);
    }
}

uint32_t Serial_Pow(uint32_t X, uint32_t Y)
{
    uint32_t Result = 1;
    while (Y--)
    {
        Result *= X;
    }
    return Result;
}

void Serial_SendNumber(uint32_t Number, uint8_t Length)
{
    uint8_t i;
    for (i = 0; i < Length; i++)
    {
        Serial_SendByte(Number / Serial_Pow(10, Length - i - 1) % 10 + '0');
    }
}

int fputc(int ch, FILE *f)
{
    Serial_SendByte(ch);
    return ch;
}

void Serial_Printf(char *format, ...)
{
    char String[100];
    va_list arg;
    va_start(arg, format);
    vsprintf(String, format, arg);
    va_end(arg);
    Serial_SendString(String);
}

uint8_t Serial_GetRxFlag(void)
{
    if (Serial_RxFlag == 1)
    {
        Serial_RxFlag = 0;
        return 1;
    }
    return 0;
}

uint8_t Serial2_GetRxFlag(void)
{
    if (Serial2_RxFlag == 1)
    {
        Serial2_RxFlag = 0;
        return 1;
    }
    return 0;
}

uint8_t Serial_GetRxData(void)
{
    return Serial_RxData;
}

uint8_t Serial2_GetRxData(void)
{
    return Serial2_RxData;
}

#define PARSE_MODE_SIMPLE 0
#define PARSE_MODE_STANDARD 1
#define PARSE_MODE_CONFIG 3

#define BUFFER_SIZE 37 // 根据实际数据包最大长度设置

// 全局变量
static uint8_t RxState = 0;                   // 当前状态
static uint8_t ParseMode = PARSE_MODE_SIMPLE; // 当前解析模式
static uint8_t pRxHead[4];
// static uint8_t pRxPacket[BUFFER_SIZE];
static uint8_t pRxHeadIndex = 0;
static uint8_t pRxPacketIndex = 0;
static uint8_t checkTailIndex = 0;
static uint8_t Serial_RxFlag = 0;
char buffer[2]; // 用于存储一个字符和终止符

// 数据解析函数
void parseData(uint8_t RxData)
{
    switch (RxState)
    {
    case 0: // 检查包头
        pRxHead[pRxHeadIndex] = RxData;
        pRxHeadIndex++;

        if (ParseMode == PARSE_MODE_STANDARD)
        {
            if (pRxHeadIndex >= 4)
            {
                if (pRxHead[0] == 0xF4 && pRxHead[1] == 0xF3 && pRxHead[2] == 0xF2 && pRxHead[3] == 0xF1)
                {
                    dataType = 1;
                    Serial_RxFlag = 0;
                    RxState = 1;
                    pRxHeadIndex = 0;
                    pRxPacketIndex = 0;
                    checkTailIndex = 0;
                }
                else
                {
                    RxState = 0;
                    pRxHeadIndex = 0;
                }
            }
        }

        break;

    case 1: // 接收数据

        if (ParseMode == PARSE_MODE_STANDARD)
        {
            if (pRxPacketIndex < BUFFER_SIZE)
            {
                Serial_RxPacket[pRxPacketIndex] = RxData;

                pRxPacketIndex++;
                if (pRxPacketIndex >= BUFFER_SIZE)
                {
                    RxState = 2;
                    pRxPacketIndex = 0;
                }
            }
        }

        break;

    case 2: // 检查包尾
        if (ParseMode == PARSE_MODE_STANDARD)
        {
            if (checkTailIndex == 0 && RxData == 0xF8)
            {
                checkTailIndex = 1;
            }
            else if (checkTailIndex == 1 && RxData == 0xF7)
            {
                checkTailIndex = 2;
            }
            else if (checkTailIndex == 2 && RxData == 0xF6)
            {
                checkTailIndex = 3;
            }
            else if (checkTailIndex == 3 && RxData == 0xF5)
            {
                Serial_RxFlag = 1;
                RxState = 0;
                checkTailIndex = 0;
            }
            else
            {
                RxState = 0;
                pRxHeadIndex = 0;
            }
        }

        break;
    }
}

// 串口1接收雷达的数据
void USART1_IRQHandler(void)
{

    if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
    {
        uint8_t RxData = USART_ReceiveData(USART1);

        // 标准数据模式
        if (RxData == 0xF4)
        {
            ParseMode = PARSE_MODE_STANDARD;
            RxState = 0;
            pRxHeadIndex = 0;
        }

        // 在接收数据时处理
        parseData(RxData);

        // 清除中断标志位
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}

// 串口2接收发送的指令
void USART2_IRQHandler(void)
{
    if (USART_GetITStatus(USART2, USART_IT_RXNE) == SET)
    {

        Serial2_RxData = USART_ReceiveData(USART2);
        Serial2_RxFlag = 1;
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
}
