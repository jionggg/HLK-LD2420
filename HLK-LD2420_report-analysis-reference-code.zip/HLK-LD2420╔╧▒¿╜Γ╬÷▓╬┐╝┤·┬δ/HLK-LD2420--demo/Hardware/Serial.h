#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>
#include <stdint.h>  // For uint8_t

extern uint8_t Serial_TxPacket[];
extern uint8_t Serial_RxPacket[];
extern uint8_t pRxHead[];

void Serial_Init(void);

void Serial2_SendByte(uint8_t Byte);
void Serial_SendByte(uint8_t Byte);

void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);

void Serial_SendPacket(void);
uint8_t Serial_GetRxFlag(void);
uint8_t Serial2_GetRxFlag(void);

uint8_t Serial_GetRxData(void);
uint8_t Serial2_GetRxData(void);

extern char buffer[2];  // 用于存储一个字符和终止符
extern int dataType;	
extern int date_Flag;
// 定义RadarPower结构体
typedef struct {
    int Gate[16];
} RadarPower;

// 定义HILINK_2420结构体
typedef struct {
    uint8_t targetstatus;
    int distance;
    RadarPower RadarPower_2420;
} HILINK_2420;

// 初始化结构体的全局变量声明
extern HILINK_2420 HLK_2420;



#endif
