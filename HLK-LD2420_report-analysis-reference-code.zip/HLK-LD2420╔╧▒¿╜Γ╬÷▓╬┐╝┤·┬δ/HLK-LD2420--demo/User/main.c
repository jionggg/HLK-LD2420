#include "stm32f10x.h" // Device header
#include "Serial.h"
#include <math.h>

uint8_t RxData;
uint8_t Rx2Data;

int main(void)
{
    Serial_Init();

    while (1)
    {

        if (Serial_GetRxFlag() == 1)
        {

            if (dataType == 1 || date_Flag == 1)
            {

                int i;
                printf("\nReceived Packet: ");
                for (i = 0; i < 37; i++)
                {
                    printf("%02X", Serial_RxPacket[i]);
                }
                printf("\n");

                //
                for (int k = 0, j = 0; k < 31; k += 2, j++)
                {

                    uint32_t power = Serial_RxPacket[5 + k] + (Serial_RxPacket[6 + k] << 8);
                    int power_2420 = log10(power) * 10;
                    HLK_2420.RadarPower_2420.Gate[j] = power_2420;
                }

                // 打印有人无人信息
                if (Serial_RxPacket[2] == 0x00)
                {
                    printf("NoTarget\n");
                }
                else if (Serial_RxPacket[2] == 0x01)
                {
                    printf("MovingTarget\n");
                }
                // 打印距离信息
                uint16_t Target_distance = Serial_RxPacket[3] + (Serial_RxPacket[4] << 8);

                printf("Target_distance:%d\n", Target_distance);

                // 打印能量值信息
                for (int i = 0; i < 16; i++)
                {
                    printf("%d gate_power:%d\n", i, HLK_2420.RadarPower_2420.Gate[i]);
                }
            }
        }

        if (Serial2_GetRxFlag() == 1)
        {
            Rx2Data = Serial2_GetRxData();
            Serial2_SendByte(Rx2Data);
            Serial_SendByte(Rx2Data);
        }
    }
}
